import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
import joblib

# ----------------------------
# 1️⃣ Load and Prepare Dataset
# ----------------------------
try:
    df = pd.read_csv('personality_dataset_numeric.csv')
    print("✅ Dataset loaded successfully.")
except FileNotFoundError:
    print("❌ Error: Dataset file not found. Please check the filename or path.")
    exit()

# Separate features and labels
x_train = df.iloc[:, 1:-1]  # Feature columns
y_train = df.iloc[:, -1]    # Target column

# ----------------------------
# 2️⃣ Train the Model
# ----------------------------
model = GradientBoostingClassifier(random_state=42)
model.fit(x_train, y_train)
print("🧠 Model training completed successfully.")

# Optionally save the model for future use
joblib.dump(model, "personality_model.pkl")
print("💾 Model saved as 'personality_model.pkl' for reuse.")

# ----------------------------
# 3️⃣ Take User Input
# ----------------------------
print("\nPlease answer the following questions (press 1 for YES, 0 for NO):\n")

features = {
    'likes_reading': int(input('📚 Do you like reading? ')),
    'likes_sports': int(input('⚽ Do you like sports? ')),
    'introvert': int(input('😶 Are you an introvert? ')),
    'likes_music': int(input('🎵 Do you like music? ')),
    'travels_often': int(input('✈️ Do you travel often? ')),
    'enjoys_cooking': int(input('👨‍🍳 Do you enjoy cooking? ')),
    'social_media_active': int(input('📱 Are you active on social media? ')),
    'morning_person': int(input('🌅 Are you a morning person? ')),
    'risk_taker': int(input('🎯 Do you consider yourself a risk taker? '))
}

# ----------------------------
# 4️⃣ Predict Personality Type
# ----------------------------
user_df = pd.DataFrame([features])  # Convert dict to DataFrame
prediction = model.predict(user_df)[0]

# ----------------------------
# 5️⃣ Display the Result
# ----------------------------
print("\n🔍 Prediction Result:")
if prediction == 1:
    print("🧩 You are an **Analytical** person — logical, detail-oriented, and data-driven.")
elif prediction == 2:
    print("🎉 You are an **Outgoing** person — energetic, social, and expressive.")
elif prediction == 3:
    print("🎨 You are a **Creative** person — imaginative, innovative, and artistic.")
else:
    print("⚙️ You are a **Practical** person — grounded, realistic, and reliable.")

print("\n✅ Prediction complete.")
