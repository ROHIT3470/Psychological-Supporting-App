from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import pandas as pd

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# Load trained model
model = joblib.load("personality_model.pkl")

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        print("\n📩 [INPUT] Received Data:")
        print(data)

        df = pd.DataFrame([data])
        print("\n📊 [DATAFRAME] Columns Detected:")
        print(df.columns.tolist())

        prediction = model.predict(df)[0]
        print(f"\n🧠 [MODEL] Raw Prediction Output: {prediction}")

        result_map = {
            1: "Analytical 🧮",
            2: "Outgoing 💬",
            3: "Creative 🎨",
            4: "Practical 🧰"
        }

        result = result_map.get(prediction, "Unknown ❓")
        print(f"\n🎯 [RESULT] Final Personality Type: {result}")

        print("\n✅ [STATUS] Prediction successful.\n" + "-"*60)

        return jsonify({'type': result})

    except Exception as e:
        print("\n❌ [ERROR] Prediction failed:")
        print(f"Details: {str(e)}\n" + "-"*60)
        return jsonify({'error': 'Prediction failed', 'details': str(e)}), 500


if __name__ == '__main__':
    print("🚀 Flask Personality Prediction API running on http://localhost:5001")
    print("------------------------------------------------------------")
    app.run(host='0.0.0.0', port=5001, debug=True)
