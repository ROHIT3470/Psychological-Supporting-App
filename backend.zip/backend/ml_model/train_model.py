import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
import joblib

# Load dataset
df = pd.read_csv('personality_dataset_numeric.csv')


x_train = df.iloc[:, 1:-1]
y_train = df.iloc[:, -1]

# Train model
model = GradientBoostingClassifier(random_state=42)
model.fit(x_train, y_train)

# Save model
joblib.dump(model, 'personality_model.pkl')
print("✅ Model trained and saved successfully.")
