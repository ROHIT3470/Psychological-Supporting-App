# Unimindcare Backend (Node + Express)


A minimal file-based backend to pair with the React frontend demo. It stores data in `db.json` (simple JSON file) and exposes REST endpoints under `/api/*`.