// 🌤️ controllers/moodController.js
import Mood from "../models/Mood.js";

/**
 * 🧠 moodController.js
 * Handles emotional data flow — from mood logging to pattern insights.
 * Designed with empathy, clarity, and analytical intelligence.
 */

// ─────────────────────────────────────────────
// 1️⃣  Add New Mood Entry
// ─────────────────────────────────────────────
export const addMood = async (req, res) => {
  try {
    const { mood, note, context, metadata } = req.body;
    const userId = req.user?._id || req.body.userId; // Fallback if middleware not yet active

    if (!userId || !mood) {
      return res.status(400).json({
        success: false,
        message: "User ID and mood score are required.",
      });
    }

    const newMood = await Mood.create({
      user: userId,
      mood,
      note,
      context,
      metadata,
    });

    res.status(201).json({
      success: true,
      data: newMood,
      message: "Mood logged successfully 🌿",
    });
  } catch (err) {
    console.error("❌ Error in addMood:", err);
    res.status(500).json({
      success: false,
      message: "Failed to log mood.",
      error: err.message,
    });
  }
};

// ─────────────────────────────────────────────
// 2️⃣  Get All Moods for a User
// ─────────────────────────────────────────────
export const getUserMoods = async (req, res) => {
  try {
    const userId = req.params.userId || req.user?._id;

    const moods = await Mood.find({ user: userId })
      .sort({ recordedAt: -1 })
      .limit(50);

    if (!moods.length) {
      return res.status(200).json({
        success: true,
        data: [],
        message: "No mood records found for this user.",
      });
    }

    res.status(200).json({
      success: true,
      count: moods.length,
      data: moods,
      message: "Mood history retrieved successfully.",
    });
  } catch (err) {
    console.error("❌ Error in getUserMoods:", err);
    res.status(500).json({
      success: false,
      message: "Failed to retrieve mood history.",
      error: err.message,
    });
  }
};

// ─────────────────────────────────────────────
// 3️⃣  Get Average Mood Score (User's baseline)
// ─────────────────────────────────────────────
export const getAverageMood = async (req, res) => {
  try {
    const userId = req.params.userId || req.user?._id;
    const avgMood = await Mood.getUserAverageMood(userId);

    res.status(200).json({
      success: true,
      averageMood: avgMood ? Number(avgMood.toFixed(2)) : null,
      message: avgMood
        ? `Average mood score: ${avgMood.toFixed(2)}`
        : "No mood records found.",
    });
  } catch (err) {
    console.error("❌ Error in getAverageMood:", err);
    res.status(500).json({
      success: false,
      message: "Failed to calculate average mood.",
      error: err.message,
    });
  }
};

// ─────────────────────────────────────────────
// 4️⃣  Get Mood Trend (last 7 or N days)
// ─────────────────────────────────────────────
export const getMoodTrend = async (req, res) => {
  try {
    const userId = req.params.userId || req.user?._id;
    const days = parseInt(req.query.days) || 7;

    const trend = await Mood.getMoodTrend(userId, days);

    res.status(200).json({
      success: true,
      data: trend,
      message: `Mood trend for the past ${days} days.`,
    });
  } catch (err) {
    console.error("❌ Error in getMoodTrend:", err);
    res.status(500).json({
      success: false,
      message: "Failed to retrieve mood trend.",
      error: err.message,
    });
  }
};

// ─────────────────────────────────────────────
// 5️⃣  Delete Mood Entry (if user wants to remove a record)
// ─────────────────────────────────────────────
export const deleteMood = async (req, res) => {
  try {
    const { id } = req.params;
    const mood = await Mood.findByIdAndDelete(id);

    if (!mood) {
      return res.status(404).json({
        success: false,
        message: "Mood entry not found.",
      });
    }

    res.status(200).json({
      success: true,
      message: "Mood entry deleted successfully.",
    });
  } catch (err) {
    console.error("❌ Error in deleteMood:", err);
    res.status(500).json({
      success: false,
      message: "Failed to delete mood entry.",
      error: err.message,
    });
  }
};
