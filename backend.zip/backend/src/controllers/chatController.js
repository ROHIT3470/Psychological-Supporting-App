/**
 * 🌟 chatController.js — Intelligent Conversational Controller
 * -------------------------------------------------------------
 * Handles all AI chat and history logic for Unimindcare.
 * Designed for clarity, resilience, and an expressive developer experience.
 * Every message is stored for emotional continuity between sessions.
 * -------------------------------------------------------------
 */

import asyncHandler from "express-async-handler";
import ChatMessage from "../models/ChatMessage.js";
import { aiReply } from "../services/ai.service.js";

/* ============================================================
   🎯 Core: Send Message and Generate AI Reply
   ============================================================ */

/*
 * @route   POST /api/chat
 * @desc    Save user message, generate AI response, persist both
 * @access  Private
 */
export const sendMessage = asyncHandler(async (req, res) => {
  const { text } = req.body;
  const userId = req.user?._id;

  // Validation and tone control
  if (!text || text.trim().length === 0) {
    return res.status(400).json({ message: "Please provide a valid message text." });
  }

  // ✍️ Step 1: Save User Message
  const userMessage = await ChatMessage.create({
    user: userId,
    from: "user",
    text: text.trim(),
    moodContext: detectMood(text),
  });

  // 🤖 Step 2: Generate AI Reply (context-aware)
  const aiText = await aiReply(text);

  // 💾 Step 3: Save AI Response
  const aiMessage = await ChatMessage.create({
    user: userId,
    from: "ai",
    text: aiText,
  });

  // 🌈 Step 4: Return both messages
  res.status(201).json({
    success: true,
    message: "Chat exchange saved successfully.",
    conversation: { userMessage, aiMessage },
  });
});

/* ============================================================
   🧠 Chat History Retrieval
   ============================================================ */

/**
 * @route   GET /api/chat
 * @desc    Fetch the full conversation history for the logged-in user
 * @access  Private
 */
export const getChat = asyncHandler(async (req, res) => {
  const userId = req.user?._id;

  // ⏳ Retrieve chat history sorted by time
  const history = await ChatMessage.find({ user: userId }).sort({ createdAt: 1 });

  if (!history.length) {
    return res.status(200).json({
      success: true,
      message: "No chat history yet. Start a conversation with your AI counselor!",
      history: [],
    });
  }

  // 🎨 Artistic response with meta info
  res.status(200).json({
    success: true,
    count: history.length,
    lastInteraction: history.at(-1)?.createdAt,
    history,
  });
});

/* ============================================================
   🌤️ Utility: Lightweight Sentiment & Mood Detection
   ============================================================ */

/**
 * Detects emotional tone for analytics or future personalization.
 * Simplified regex-based heuristic (non-ML placeholder).
 */
function detectMood(text) {
  const t = text.toLowerCase();
  if (/(sad|depress|tired|down|upset|cry)/.test(t)) return "low";
  if (/(stress|nervous|anxious|worried)/.test(t)) return "anxious";
  if (/(happy|good|excited|grateful|love|great)/.test(t)) return "positive";
  if (/(angry|mad|furious|frustrated)/.test(t)) return "angry";
  return "neutral";
}

/* ============================================================
   💫 Additional Optional Exports
   ============================================================ */

/**
 * Clears user’s chat history (Admin/Development purpose)
 */
export const clearChat = asyncHandler(async (req, res) => {
  const userId = req.user?._id;
  await ChatMessage.deleteMany({ user: userId });
  res.status(200).json({ success: true, message: "Chat history cleared successfully." });
});

/**
 * ✨ Artistic summary of file’s function:
 * 
 * This controller forms the bridge between empathy and logic.
 * Each user message is handled as a moment of trust.
 * The AI reply is designed to be not just reactive — but gently guiding.
 * Together, they form a digital conversation that listens, remembers, and supports.
 */
