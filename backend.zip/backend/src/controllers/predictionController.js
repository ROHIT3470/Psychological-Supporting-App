import axios from "axios";
import Prediction from "../models/Prediction.js";

export const predictPersonality = async (req, res) => {
  try {
    const userAnswers = req.body;

    // Send data to Flask ML API
    const response = await axios.post("http://127.0.0.1:5000/predict", userAnswers);
    const result = response.data;

    // Extract correct fields from Flask response
    const personalityType = result.personality_type || "Unknown";
    const predictionValue = result.prediction || null;

    // Save the prediction result in MongoDB
    const savedPrediction = await Prediction.create({
      userId: null, // You can later map this to logged-in user
      answers: userAnswers,
      resultType: personalityType, // previously result.type — fixed!
      rawPrediction: predictionValue, // optional field for model output
    });

    // Send full response back to frontend
    res.status(200).json({
      message: "Prediction successful",
      prediction: {
        prediction: predictionValue,
        personality_type: personalityType,
      },
      dbEntry: savedPrediction,
    });
  } catch (error) {
    console.error("❌ Prediction error:", error.response?.data || error.message);
    res.status(500).json({
      error: "Prediction failed",
      details: error.response?.data || error.message,
    });
  }
};
