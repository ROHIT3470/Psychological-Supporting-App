/**
 * 🌿 activityController.js (Enhanced for Unimindcare)
 *
 * Handles the logic for fetching, creating, and logging user interaction with
 * mood-boosting activities — each designed to nurture mindfulness, positivity,
 * and self-care. This upgraded version emphasizes structured responses,
 * role-based security, and graceful error handling.
 *
 * 🧠 Models:
 *  - Activity (Stores all available wellbeing activities)
 *  - UserActivityLog (Tracks user participation/completion)
 *
 * 🌐 Routes:
 *  GET    /api/activities                → Get all activities
 *  POST   /api/activities                → Admin-only: Add new activity
 *  POST   /api/activities/log-completion → Log a user’s completion
 */

import asyncHandler from 'express-async-handler';
import Activity from '../models/Activity.js';
import UserActivityLog from '../models/UserActivityLog.js';

/* ============================================================
   🌸 Utility: Consistent API Response Structure
============================================================ */
const sendResponse = (res, statusCode, success, message, data = null, extra = {}) => {
  return res.status(statusCode).json({
    success,
    message,
    data,
    ...extra,
  });
};

/* ============================================================
   🌻 GET /api/activities → Fetch All Mood-Boosting Activities
============================================================ */
export const getActivities = asyncHandler(async (req, res) => {
  try {
    // Fetch active activities sorted alphabetically or by creation date
    const activities = await Activity.find({ isActive: true }).sort({ title: 1 });

    if (!activities.length) {
      return sendResponse(res, 200, true, 'No activities found — consider adding new ones.', []);
    }

    return sendResponse(res, 200, true, 'Activities retrieved successfully.', activities, {
      count: activities.length,
    });
  } catch (error) {
    console.error('❌ [getActivities] Error:', error);
    return sendResponse(res, 500, false, 'Server Error: Unable to fetch activities.');
  }
});

/* ============================================================
   💫 POST /api/activities/log-completion → Log a User’s Completion
============================================================ */
export const logActivityCompletion = asyncHandler(async (req, res) => {
  if (!req.user) {
    return sendResponse(res, 401, false, 'Unauthorized: Please log in to record your progress.');
  }

  const { activityId, moodBefore, moodAfter } = req.body;

  if (!activityId) {
    return sendResponse(res, 400, false, 'Activity ID is required to log completion.');
  }

  try {
    // Verify activity existence
    const activity = await Activity.findById(activityId);
    if (!activity) {
      return sendResponse(res, 404, false, 'Activity not found. Please check the ID.');
    }

    // Prevent duplicate same-day logs (optional)
    const existingLog = await UserActivityLog.findOne({
      userId: req.user._id,
      activityId,
      completionDate: { $gte: new Date().setHours(0, 0, 0, 0) },
    });

    if (existingLog) {
      return sendResponse(res, 400, false, 'You have already logged this activity today.');
    }

    // Create a new completion log
    const logEntry = await UserActivityLog.create({
      userId: req.user._id,
      activityId,
      completionDate: new Date(),
      moodBefore,
      moodAfter,
    });

    return sendResponse(
      res,
      201,
      true,
      `✅ You successfully completed "${activity.title}". Great job taking a step for yourself!`,
      logEntry
    );
  } catch (error) {
    console.error('⚠️ [logActivityCompletion] Error:', error);
    const message =
      error.name === 'ValidationError'
        ? error.message
        : 'Server Error: Could not log your activity. Please try again.';
    return sendResponse(res, 500, false, message);
  }
});

/* ============================================================
   🌼 POST /api/activities → Admin: Create a New Activity
============================================================ */
export const createActivity = asyncHandler(async (req, res) => {
  if (!req.user || req.user.role !== 'admin') {
    return sendResponse(res, 403, false, 'Forbidden: Only admins can create new activities.');
  }

  const { title, dur, desc, category, isActive = true } = req.body;

  if (!title || !desc || !dur) {
    return sendResponse(res, 400, false, 'Please provide all required fields (title, desc, dur).');
  }

  try {
    const newActivity = await Activity.create({
      title,
      dur,
      desc,
      category: category || 'General Wellness',
      createdBy: req.user._id,
      isActive,
    });

    return sendResponse(
      res,
      201,
      true,
      `🌿 New activity "${newActivity.title}" added successfully!`,
      newActivity
    );
  } catch (error) {
    console.error('🔥 [createActivity] Error:', error);
    const message =
      error.name === 'ValidationError'
        ? error.message
        : 'Server Error: Could not create the new activity.';
    return sendResponse(res, 500, false, message);
  }
});

/* ============================================================
   🌙 (Optional) GET /api/activities/user → Get User’s Activity Logs
============================================================ */
export const getUserActivityLogs = asyncHandler(async (req, res) => {
  if (!req.user) {
    return sendResponse(res, 401, false, 'Unauthorized: Please log in first.');
  }

  try {
    const logs = await UserActivityLog.find({ userId: req.user._id })
      .populate('activityId', 'title dur desc')
      .sort({ completionDate: -1 });

    if (!logs.length) {
      return sendResponse(res, 200, true, 'No activity logs found.', []);
    }

    return sendResponse(res, 200, true, 'User activity logs retrieved successfully.', logs, {
      total: logs.length,
    });
  } catch (error) {
    console.error('💥 [getUserActivityLogs] Error:', error);
    return sendResponse(res, 500, false, 'Server Error: Unable to fetch activity logs.');
  }
});

/* ============================================================
   🌺 Example Route Setup (activityRoutes.js)
============================================================ */
// import express from 'express';
// import { protect, admin } from '../middleware/authMiddleware.js';
// import {
//   getActivities,
//   createActivity,
//   logActivityCompletion,
//   getUserActivityLogs
// } from '../controllers/activityController.js';

// const router = express.Router();
// router.route('/').get(getActivities).post(protect, admin, createActivity);
// router.route('/log-completion').post(protect, logActivityCompletion);
// router.route('/user').get(protect, getUserActivityLogs);
// export default router;
