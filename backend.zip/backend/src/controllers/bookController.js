/**
 * bookController.js
 *
 * Controller for handling appointment booking logic.
 * Assumes an Express.js router is calling these functions.
 * Assumes a database module (`db`) is available for persistence (e.g., MongoDB, PostgreSQL).
 */

// 1. Import necessary modules (e.g., database connection, validation)
const Appointment = require('../models/AppointmentModel'); // Assuming an Mongoose or Sequelize model
const Counselor = require('../models/CounselorModel'); // Assuming a Counselor model
const { sendConfirmationEmail } = require('../services/emailService'); // Assuming an email service

/**
 * @desc Book a new counseling session appointment
 * @route POST /api/v1/appointments
 * @access Private (Student)
 */
exports.bookAppointment = async (req, res) => {
    // Frontend sends data in req.body. Example structure from frontend:
    // { counselorId, mode, name, email, date, time, concerns }
    const { counselorId, mode, name, email, date, time, concerns } = req.body;

    // --- Basic Input Validation ---
    if (!counselorId || !mode || !name || !email || !date || !time) {
        return res.status(400).json({ success: false, error: 'Missing required booking fields.' });
    }

    try {
        // 1. Check if the counselor exists and is available
        const counselor = await Counselor.findById(counselorId);
        if (!counselor) {
            return res.status(404).json({ success: false, error: 'Counselor not found.' });
        }

        // 2. Check for time slot availability (Complex logic, simplified here)
        // In a real app, this would query the DB for existing appointments
        // for the specific counselor, date, and time.
        const isAvailable = await Appointment.checkAvailability(counselorId, date, time);
        if (!isAvailable) {
            return res.status(409).json({ success: false, error: 'Time slot is already booked.' });
        }

        // 3. Create the new appointment record in the database
        const newAppointment = await Appointment.create({
            studentName: name, // Using 'name' from frontend
            studentEmail: email,
            counselor: counselorId,
            sessionMode: mode,
            date,
            time,
            concerns,
            status: 'Pending'
        });

        // 4. Send a confirmation email (as suggested in the frontend code)
        await sendConfirmationEmail(email, newAppointment);
        
        // 5. Respond with the created appointment details
        res.status(201).json({ 
            success: true, 
            data: newAppointment, 
            message: 'Appointment successfully booked. Confirmation email sent.' 
        });

    } catch (error) {
        console.error("Booking error:", error);
        res.status(500).json({ success: false, error: 'Server error during booking.' });
    }
};

// -----------------------------------------------------------------------------

/**
 * @desc Get all appointments for the logged-in student
 * @route GET /api/v1/appointments/my
 * @access Private (Student)
 */
exports.getStudentAppointments = async (req, res) => {
    try {
        // Assuming user ID is available from authentication middleware (req.user.id)
        const studentId = req.user.id; 

        const appointments = await Appointment.find({ student: studentId })
                                              .populate('counselor', 'name role') // Fetch counselor name and role
                                              .sort({ date: -1, time: -1 });

        res.status(200).json({ success: true, count: appointments.length, data: appointments });
    } catch (error) {
        console.error("Fetch appointments error:", error);
        res.status(500).json({ success: false, error: 'Server error retrieving appointments.' });
    }
};

// -----------------------------------------------------------------------------

/**
 * @desc Cancel a specific appointment
 * @route DELETE /api/v1/appointments/:id
 * @access Private (Student/Counselor)
 */
exports.cancelAppointment = async (req, res) => {
    const { id } = req.params;

    try {
        const appointment = await Appointment.findById(id);

        if (!appointment) {
            return res.status(404).json({ success: false, error: 'Appointment not found.' });
        }

        // 1. Authorization check: ensure the current user can cancel this appointment
        // (e.g., only the booking student or the assigned counselor)
        if (appointment.student.toString() !== req.user.id && req.user.role !== 'counselor') {
            return res.status(403).json({ success: false, error: 'Not authorized to cancel this appointment.' });
        }
        
        // 2. Update status or delete from DB
        // For good record-keeping, it's often better to update status to 'Cancelled'
        await Appointment.findByIdAndUpdate(id, { status: 'Cancelled' });

        // 3. Send cancellation confirmation
        // await sendCancellationEmail(appointment.studentEmail, appointment);

        res.status(200).json({ success: true, message: 'Appointment successfully cancelled.' });
    } catch (error) {
        console.error("Cancel appointment error:", error);
        res.status(500).json({ success: false, error: 'Server error during cancellation.' });
    }
};

// -----------------------------------------------------------------------------