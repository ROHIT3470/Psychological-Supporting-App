// 🌤️ models/Mood.js
import mongoose from "mongoose";

const { Schema } = mongoose;

/**
 * 🌈 Mood Schema
 * A refined emotional data model — turning feelings into insights.
 * Tracks user moods, reflections, and contextual metadata for analytics & wellness patterns.
 */

const moodSchema = new Schema(
  {
    // 🧍 Reference to the user whose mood is tracked
    user: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },

    // 🎭 Mood rating (1 = very low, 5 = excellent)
    mood: {
      type: Number,
      required: true,
      min: [1, "Mood cannot be less than 1"],
      max: [5, "Mood cannot be greater than 5"],
    },

    // 🪞 Short reflective note from the user
    note: {
      type: String,
      trim: true,
      maxlength: [500, "Note cannot exceed 500 characters"],
      default: "",
    },

    // 🕒 Optionally track mood by session, event, or tag
    context: {
      type: String,
      trim: true,
      maxlength: 100,
      default: "daily",
    },

    // 📍 Environmental or situational context (optional)
    metadata: {
      weather: { type: String, trim: true },
      location: { type: String, trim: true },
      activity: { type: String, trim: true },
      stressLevel: {
        type: Number,
        min: 1,
        max: 10,
      },
    },

    // 💭 AI insights or pattern recognition results
    insight: {
      type: String,
      trim: true,
      maxlength: 1000,
    },

    // 🌅 Optional timestamp override — track mood for a specific day/time
    recordedAt: {
      type: Date,
      default: Date.now,
      index: true,
    },
  },
  {
    timestamps: true, // createdAt, updatedAt
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

//
// 🧠 Virtuals
//

// ⏰ Readable date (localized for India)
moodSchema.virtual("formattedDate").get(function () {
  return this.recordedAt
    ? this.recordedAt.toLocaleDateString("en-IN", {
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
      })
    : "";
});

// ❤️ Emoji representation of mood
moodSchema.virtual("moodEmoji").get(function () {
  const emojiMap = {
    1: "😞",
    2: "😕",
    3: "😐",
    4: "🙂",
    5: "😄",
  };
  return emojiMap[this.mood] || "❓";
});

// 💬 Short mood summary
moodSchema.virtual("summary").get(function () {
  const moodLabels = {
    1: "Very Low",
    2: "Low",
    3: "Neutral",
    4: "Good",
    5: "Excellent",
  };
  return `${moodLabels[this.mood]} mood ${this.moodEmoji}`;
});

//
// 🚀 Indexes for performance
//
moodSchema.index({ user: 1, recordedAt: -1 });
moodSchema.index({ mood: 1 });
moodSchema.index({ context: 1 });

//
// ⚙️ Static Methods
//
moodSchema.statics.getUserAverageMood = async function (userId) {
  const result = await this.aggregate([
    { $match: { user: userId } },
    { $group: { _id: "$user", avgMood: { $avg: "$mood" } } },
  ]);
  return result[0]?.avgMood || null;
};

moodSchema.statics.getMoodTrend = async function (userId, days = 7) {
  const since = new Date();
  since.setDate(since.getDate() - days);
  return this.aggregate([
    { $match: { user: userId, recordedAt: { $gte: since } } },
    {
      $group: {
        _id: { $dateToString: { format: "%Y-%m-%d", date: "$recordedAt" } },
        avgMood: { $avg: "$mood" },
      },
    },
    { $sort: { _id: 1 } },
  ]);
};

//
// 🪶 Pre-save Hook
//
moodSchema.pre("save", function (next) {
  // Clean up any redundant whitespace in note/context
  if (this.note) this.note = this.note.trim();
  if (this.context) this.context = this.context.trim();

  // Auto-generate a simple insight if not set
  if (!this.insight) {
    const moodTexts = {
      1: "It seems like a tough day. Try gentle self-care.",
      2: "You might be feeling a bit low — maybe take a short walk.",
      3: "Balanced mood. A calm state is good progress.",
      4: "You're feeling positive today — celebrate that energy.",
      5: "Excellent mood! Keep spreading your light 🌞",
    };
    this.insight = moodTexts[this.mood] || "Mood recorded successfully.";
  }

  next();
});

//
// 🌍 Model Export
//
const Mood = mongoose.model("Mood", moodSchema);
export default Mood;
