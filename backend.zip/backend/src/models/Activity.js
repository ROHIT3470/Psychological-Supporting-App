// Activity.js (Express Router Module for Activity Management)

/**
 * Required Libraries:
 * - express: For creating the router and defining routes.
 * - [db/ActivityModel]: A placeholder for your actual database model (e.g., Mongoose schema, Sequelize model)
 * to interact with the 'activities' collection/table.
 */
const express = require('express');
const router = express.Router();

// --- 1. Data Model & Mock Data (Replace with Database Connection/Model) ---
// This mock data mirrors the structure in the frontend HTML for initial setup.
const mockActivities = [
  { id: 'breathing', title: '2-minute Box Breathing', duration: '2–4 min', description: 'Inhale 4s, hold 4s, exhale 4s, hold 4s. Repeat.', category: 'relaxation', targetMood: 'stress' },
  { id: 'journaling', title: 'Quick Mood Journal', duration: '5 min', description: 'Write 3 sentences: what happened, how you felt, one small action.', category: 'reflection', targetMood: 'sadness' },
  { id: 'movement', title: 'Light Movement Break', duration: '5–10 min', description: 'Gentle stretches or a short walk.', category: 'physical', targetMood: 'low-energy' },
  { id: 'gratitude', title: 'Gratitude Trio', duration: '3 min', description: 'List 3 things you’re grateful for today.', category: 'positivity', targetMood: 'all' },
  { id: 'music', title: 'Listen to Calming Music', duration: '10 min', description: 'Put on some calm music or white noise.', category: 'relaxation', targetMood: 'anxiety' },
  { id: 'connect', title: 'Check-in with a Friend', duration: '5 min', description: 'Send a quick text or call a friend.', category: 'social', targetMood: 'loneliness' },
];

/**
 * Placeholder for DB interaction functions.
 * In a real app, these would use your ORM (e.g., Mongoose, Prisma) to query the database.
 */
// async function findAllActivities() { return await ActivityModel.find({}); }
// async function logUserActivity(userId, activityId) { /* DB insertion logic */ }
// async function findActivitiesByMood(mood) { /* DB query logic */ }


// --- 2. API Endpoints/Routes ---

/**
 * GET /api/activities
 * Fetches the full list of available mood-boosting activities.
 * Can be filtered by a query parameter like 'mood'.
 */
router.get('/', (req, res) => {
  const { mood } = req.query; // e.g., /api/activities?mood=stress
  let activities = mockActivities;

  if (mood) {
    // In a real app, you'd use a robust DB query for this.
    activities = mockActivities.filter(a => a.targetMood.includes(mood) || a.targetMood === 'all');
    if (activities.length === 0) {
      // Fallback if no specific activities match the mood
      activities = mockActivities.filter(a => a.category === 'relaxation' || a.category === 'positivity').slice(0, 3);
    }
  }

  // Response: Status 200 OK and the list of activities
  res.status(200).json({
    success: true,
    data: activities,
    message: 'Activities list retrieved successfully.'
  });
});

/**
 * POST /api/activities/log
 * Logs a user's completion of an activity.
 * This is crucial for tracking engagement and providing better insights.
 */
router.post('/log', async (req, res) => {
  // ⚠️ IMPORTANT: In a real application, you must verify the user (via session/token)
  // and validate the request body before processing.
  const { userId, activityId, note } = req.body;

  if (!userId || !activityId) {
    return res.status(400).json({ success: false, message: 'Missing userId or activityId.' });
  }

  // Find the activity to ensure it's valid
  const activity = mockActivities.find(a => a.id === activityId);
  if (!activity) {
    return res.status(404).json({ success: false, message: 'Activity not found.' });
  }

  // 📝 Placeholder for database log entry:
  const logEntry = {
    userId,
    activityId,
    timestamp: new Date().toISOString(),
    activityTitle: activity.title,
    note // optional note from the user
  };

  // ➡️ In a real app: await logUserActivity(logEntry);

  // Response: Status 201 Created
  res.status(201).json({
    success: true,
    data: logEntry,
    message: `Activity "${activity.title}" logged successfully for user ${userId}.`
  });
});

/**
 * GET /api/activities/history/:userId
 * Fetches the logged activity history for a specific user.
 */
router.get('/history/:userId', (req, res) => {
    // ⚠️ IMPORTANT: Authentication/Authorization check needed here to ensure
    // the requesting user can only see their own history.
    const { userId } = req.params;

    // 📝 Placeholder for database history retrieval:
    // ➡️ In a real app: const history = await findUserActivityHistory(userId);
    const mockHistory = [
        { activityTitle: '2-minute Box Breathing', timestamp: '2025-10-10T14:30:00Z' },
        { activityTitle: 'Quick Mood Journal', timestamp: '2025-10-09T09:15:00Z' }
    ];

    res.status(200).json({
        success: true,
        data: mockHistory,
        message: `Activity history for user ${userId} retrieved.`
    });
});


// --- 3. Export the Router ---
module.exports = router;