import mongoose from "mongoose";

// =============================
// 🎯 Appointment Schema
// =============================
const appointmentSchema = new mongoose.Schema(
  {
    // 👤 User who booked the appointment
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: [true, "Booking must be associated with a user."],
    },

    // 🧑‍⚕️ Counselor assigned (optional if counselorName is stored separately)
    counselor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Counselor",
    },

    // 🪶 Human-readable fallback if counselor account is deleted
    counselorName: {
      type: String,
      required: [true, "Counselor name is required."],
      trim: true,
      minlength: [3, "Counselor name must be at least 3 characters long."],
      maxlength: [100, "Counselor name cannot exceed 100 characters."],
    },

    // 🌐 Session mode — physical or virtual
    mode: {
      type: String,
      enum: ["In-person", "Online"],
      required: true,
      default: "Online",
    },

    // 📅 Appointment date & time
    date: {
      type: Date,
      required: [true, "Please specify the appointment date."],
      validate: {
        validator: function (value) {
          return value >= new Date();
        },
        message: "Appointment date cannot be in the past.",
      },
    },

    time: {
      type: String,
      required: [true, "Please specify the appointment time."],
      match: [
        /^([0-1]\d|2[0-3]):([0-5]\d)$/,
        "Invalid time format. Use 24-hour format (HH:mm).",
      ],
    },

    // 💭 Client’s concern / reason for booking
    concerns: {
      type: String,
      trim: true,
      maxlength: [500, "Concerns cannot exceed 500 characters."],
    },

    // 🔄 Appointment lifecycle state
    status: {
      type: String,
      enum: ["booked", "rescheduled", "completed", "cancelled"],
      default: "booked",
    },

    // 🔗 Meeting link (for online sessions)
    meetingLink: {
      type: String,
      trim: true,
      validate: {
        validator: function (value) {
          if (!value) return true;
          return /^https?:\/\/[\w.-]+(?:\.[\w\.-]+)+[/#?]?.*$/.test(value);
        },
        message: "Invalid meeting link format.",
      },
    },

    // 🕊️ Notes after completion (for counselors/admins)
    notes: {
      type: String,
      trim: true,
      maxlength: [1000, "Notes cannot exceed 1000 characters."],
    },

    // 🪶 Tracks who last updated (rescheduled / cancelled)
    lastUpdatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },

    // 📈 Meta tracking
    rescheduleCount: {
      type: Number,
      default: 0,
      min: 0,
    },

    // 🌟 Soft delete flag (optional, non-destructive deletion)
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true, // ⏰ createdAt & updatedAt
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// =============================
// ✨ Virtuals
// =============================

// 🗓️ Readable date format (like "6 Nov 2025")
appointmentSchema.virtual("formattedDate").get(function () {
  return this.date
    ? this.date.toLocaleDateString("en-IN", {
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
      })
    : "";
});

// 🕒 Combined readable datetime
appointmentSchema.virtual("displaySlot").get(function () {
  return this.date && this.time
    ? `${this.formattedDate} at ${this.time}`
    : "";
});

// =============================
// ⚙️ Indexes for performance
// =============================
appointmentSchema.index({ user: 1, date: 1 });
appointmentSchema.index({ counselor: 1, date: 1 });
appointmentSchema.index({ status: 1 });

// =============================
// 🧠 Pre-save Hook — Increment reschedule count
// =============================
appointmentSchema.pre("save", function (next) {
  if (this.isModified("date") || this.isModified("time")) {
    if (this.isNew === false && this.status === "rescheduled") {
      this.rescheduleCount += 1;
    }
  }
  next();
});

// =============================
// 🕊️ Helper Methods
// =============================

// Marks appointment as cancelled
appointmentSchema.methods.cancel = function (userId) {
  this.status = "cancelled";
  this.lastUpdatedBy = userId;
  this.isActive = false;
  return this.save();
};

// Marks appointment as completed
appointmentSchema.methods.complete = function (userId) {
  this.status = "completed";
  this.lastUpdatedBy = userId;
  return this.save();
};

// =============================
// 🌿 Export Model
// =============================
export default mongoose.model("Appointment", appointmentSchema);
