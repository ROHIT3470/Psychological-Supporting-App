// models/Prediction.js
import mongoose from "mongoose";

const predictionSchema = new mongoose.Schema(
  {
    // 👤 The user who generated the prediction
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },

    // 🧠 The answers used for prediction (structured for flexibility)
    answers: {
      type: Map, // stores dynamic key-value pairs (Q1: "Yes", Q2: 5, etc.)
      of: mongoose.Schema.Types.Mixed,
      required: true,
    },

    // 🧩 The prediction result (e.g., "INTJ", "Calm", "Extrovert", etc.)
    resultType: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100,
    },

    // 📊 Confidence or probability score from the ML model (optional)
    confidence: {
      type: Number,
      min: 0,
      max: 1,
      default: null,
    },

    // ⚙️ Type of model used (AI, ML, or manual)
    modelType: {
      type: String,
      enum: ["AI", "ML", "Manual"],
      default: "AI",
    },

    // 🏷️ Optional tags (categories, personality traits, etc.)
    tags: {
      type: [String],
      default: [],
    },

    // 📆 Optional field to track test type or version (for multiple tests)
    testVersion: {
      type: String,
      trim: true,
      default: "v1.0",
    },

    // 📈 Aggregated summary text or explanation
    summary: {
      type: String,
      trim: true,
      maxlength: 1000,
    },

    // 🕓 Automatically managed timestamps
  },
  { timestamps: true }
);

// 🔍 Index for efficient user-based lookups and result filtering
predictionSchema.index({ user: 1, resultType: 1, createdAt: -1 });

// 🧮 Virtual field: short readable date
predictionSchema.virtual("formattedDate").get(function () {
  return this.createdAt
    ? this.createdAt.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })
    : "";
});

// 🧠 Pre-save hook: auto-tag based on resultType
predictionSchema.pre("save", function (next) {
  if (this.resultType && !this.tags.length) {
    this.tags = [this.resultType.toLowerCase()];
  }
  next();
});

export default mongoose.model("Prediction", predictionSchema);
