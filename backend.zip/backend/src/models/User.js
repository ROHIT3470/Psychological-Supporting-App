// models/User.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import crypto from "crypto";

const userSchema = new mongoose.Schema(
  {
    // 👤 Basic details
    name: {
      type: String,
      required: [true, "Name is required"],
      trim: true,
      minlength: [2, "Name must be at least 2 characters"],
      maxlength: [50, "Name cannot exceed 50 characters"],
    },

    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, "Please enter a valid email address"],
    },

    password: {
      type: String,
      required: [true, "Password is required"],
      minlength: [6, "Password must be at least 6 characters"],
      select: false, // never return password by default
    },

    // 🧩 Role-based access
    role: {
      type: String,
      enum: ["user", "counselor", "admin"],
      default: "user",
    },

    // 🌍 Optional profile info
    avatar: {
      type: String,
      default: "https://via.placeholder.com/150",
    },

    phone: {
      type: String,
      trim: true,
      match: [/^[0-9]{10}$/, "Please enter a valid 10-digit phone number"],
    },

    // 🧠 Mental health preferences (optional for personalization)
    preferences: {
      theme: { type: String, enum: ["light", "dark"], default: "light" },
      language: { type: String, default: "en" },
    },

    // 🔒 Password reset tokens
    resetPasswordToken: String,
    resetPasswordExpire: Date,
  },
  { timestamps: true }
);

//
// 🔐 Middleware: Hash password before saving
//
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  const salt = await bcrypt.genSalt(12);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

//
// 🧾 Instance method: Compare entered password with hashed password
//
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

//
// 🧩 Instance method: Generate password reset token
//
userSchema.methods.getResetPasswordToken = function () {
  const resetToken = crypto.randomBytes(20).toString("hex");

  // Hash token and set to resetPasswordToken field
  this.resetPasswordToken = crypto.createHash("sha256").update(resetToken).digest("hex");

  // Token expires in 10 minutes
  this.resetPasswordExpire = Date.now() + 10 * 60 * 1000;

  return resetToken;
};

//
// 💡 Virtuals: Full profile summary (for frontend display)
//
userSchema.virtual("profileSummary").get(function () {
  return {
    name: this.name,
    email: this.email,
    role: this.role,
    avatar: this.avatar,
  };
});

//
// 🔍 Indexing for faster lookups
//
userSchema.index({ email: 1 });

export default mongoose.model("User", userSchema);
