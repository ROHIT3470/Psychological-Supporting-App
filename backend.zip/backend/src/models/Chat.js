// 🌐 models/Chat.js
import mongoose from "mongoose";

const { Schema } = mongoose;

/**
 * 🧠 Chat Schema
 * Elegant, efficient, and future-ready model for managing user–counselor–AI conversations.
 * Designed to support text, media, and structured conversational data.
 */

const attachmentSchema = new Schema(
  {
    fileUrl: {
      type: String,
      trim: true,
      validate: {
        validator: (v) => /^https?:\/\/.+/i.test(v),
        message: "Invalid file URL format.",
      },
    },
    fileType: {
      type: String,
      trim: true,
      enum: ["image", "audio", "video", "document", "other"],
      default: "other",
    },
    fileName: {
      type: String,
      trim: true,
      maxlength: 200,
    },
    fileSize: {
      type: Number, // in bytes
      min: [0, "File size cannot be negative"],
    },
  },
  { _id: false }
);

const chatSchema = new Schema(
  {
    // 👥 Linked participants
    user: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    counselor: {
      type: Schema.Types.ObjectId,
      ref: "Counselor",
    },

    // 💬 Core message content
    senderType: {
      type: String,
      enum: ["user", "counselor", "ai"],
      required: true,
    },
    message: {
      type: String,
      trim: true,
      maxlength: [4000, "Message exceeds 4000 characters."],
      required: function () {
        return this.attachments.length === 0;
      },
    },

    // 📎 Attachments
    attachments: {
      type: [attachmentSchema],
      validate: {
        validator: (arr) => arr.length <= 5,
        message: "A message can contain up to 5 attachments only.",
      },
    },

    // 🧩 Grouping per chat session
    sessionId: {
      type: String,
      trim: true,
      index: true,
      default: function () {
        return `${this.user}_${new Date().toISOString().split("T")[0]}`;
      },
    },

    // 🔖 Message states
    isRead: { type: Boolean, default: false },
    isEdited: { type: Boolean, default: false },
    isDeleted: { type: Boolean, default: false },

    // 🕒 Timings
    sentAt: { type: Date, default: Date.now },
    readAt: { type: Date },
    editedAt: { type: Date },

    // 🧠 AI metadata (for future extensions)
    aiContext: {
      promptId: { type: String, trim: true },
      responseTime: { type: Number }, // milliseconds
      modelUsed: { type: String, trim: true },
      confidenceScore: { type: Number, min: 0, max: 1 },
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

//
// 🌟 VIRTUALS
//
chatSchema.virtual("formattedTime").get(function () {
  return this.sentAt
    ? this.sentAt.toLocaleTimeString("en-IN", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
      })
    : "";
});

chatSchema.virtual("formattedDate").get(function () {
  return this.sentAt
    ? this.sentAt.toLocaleDateString("en-IN", {
        weekday: "short",
        day: "2-digit",
        month: "short",
        year: "numeric",
      })
    : "";
});

//
// 🚀 INDEXES
//
chatSchema.index({ user: 1, sessionId: 1, sentAt: 1 });
chatSchema.index({ counselor: 1, sessionId: 1 });
chatSchema.index({ isRead: 1 });
chatSchema.index({ isDeleted: 1 });

//
// 🧩 QUERY HELPERS
//
chatSchema.query.byUser = function (userId) {
  return this.where({ user: userId, isDeleted: false });
};

chatSchema.query.bySession = function (sessionId) {
  return this.where({ sessionId, isDeleted: false });
};

chatSchema.query.unread = function () {
  return this.where({ isRead: false, isDeleted: false });
};

//
// 🛠️ MIDDLEWARE
//

// Update timestamp when message is edited
chatSchema.pre("save", function (next) {
  if (this.isModified("message")) {
    this.isEdited = true;
    this.editedAt = new Date();
  }
  next();
});

// Soft delete middleware
chatSchema.methods.softDelete = async function () {
  this.isDeleted = true;
  await this.save();
};

//
// 🧭 MODEL EXPORT
//
const Chat = mongoose.model("Chat", chatSchema);
export default Chat;
