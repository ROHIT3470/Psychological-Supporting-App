// 🌟 models/Counselor.js
import mongoose from "mongoose";

const { Schema } = mongoose;

/**
 * 🧠 Counselor Schema
 * A graceful, scalable representation of professional counselors.
 * Designed for platforms that combine psychology, empathy, and technology.
 */

const availabilitySchema = new Schema(
  {
    day: {
      type: String,
      enum: [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
      ],
      required: true,
    },
    startTime: {
      type: String,
      match: [/^([0-1]\d|2[0-3]):([0-5]\d)$/, "Invalid start time (HH:mm)"],
      required: true,
    },
    endTime: {
      type: String,
      match: [/^([0-1]\d|2[0-3]):([0-5]\d)$/, "Invalid end time (HH:mm)"],
      required: true,
    },
    isAvailable: {
      type: Boolean,
      default: true,
    },
  },
  { _id: false }
);

const counselorSchema = new Schema(
  {
    // 🪪 Identity
    name: {
      type: String,
      required: true,
      trim: true,
      minlength: [2, "Name must be at least 2 characters long."],
      maxlength: [100, "Name cannot exceed 100 characters."],
    },

    role: {
      type: String,
      required: true,
      enum: [
        "Clinical Psychologist",
        "Counselor",
        "Student Supporter",
        "Therapist",
        "Psychiatrist",
      ],
    },

    bio: {
      type: String,
      trim: true,
      maxlength: [1000, "Bio cannot exceed 1000 characters."],
      default: "Dedicated mental health professional.",
    },

    // 🎓 Professional Info
    expertise: {
      type: [String],
      required: true,
      validate: {
        validator: (arr) => arr.length > 0,
        message: "At least one expertise area is required.",
      },
    },

    experienceYears: {
      type: Number,
      min: 0,
      max: 60,
      default: 3,
    },

    certifications: [
      {
        title: { type: String, trim: true },
        institution: { type: String, trim: true },
        year: { type: Number },
      },
    ],

    // 🌐 Modes
    mode: {
      type: [String],
      enum: ["In-person", "Online"],
      default: ["Online"],
    },

    // 📞 Contact
    contactEmail: {
      type: String,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, "Please provide a valid email address"],
    },
    phone: {
      type: String,
      trim: true,
      match: [/^\+?\d{10,15}$/, "Please provide a valid phone number"],
    },

    // 🗓️ Schedule
    availableDays: {
      type: [availabilitySchema],
      default: [
        { day: "Monday", startTime: "09:00", endTime: "17:00" },
        { day: "Wednesday", startTime: "09:00", endTime: "17:00" },
        { day: "Friday", startTime: "09:00", endTime: "17:00" },
      ],
    },

    // 📍 Location (optional: for in-person sessions)
    location: {
      address: { type: String, trim: true },
      city: { type: String, trim: true },
      state: { type: String, trim: true },
      coordinates: {
        type: { type: String, enum: ["Point"], default: "Point" },
        coordinates: { type: [Number], default: [0, 0] }, // [longitude, latitude]
      },
    },

    // 🧾 Ratings & Reviews
    rating: {
      type: Number,
      min: 0,
      max: 5,
      default: 4.5,
    },
    totalReviews: {
      type: Number,
      default: 0,
    },
    reviews: [
      {
        user: { type: Schema.Types.ObjectId, ref: "User" },
        rating: { type: Number, min: 0, max: 5 },
        feedback: { type: String, trim: true, maxlength: 500 },
        createdAt: { type: Date, default: Date.now },
      },
    ],

    // 🖼️ Media
    profileImage: {
      type: String,
      trim: true,
      default: "https://via.placeholder.com/150",
      validate: {
        validator: (v) => /^https?:\/\/.+/i.test(v),
        message: "Invalid profile image URL.",
      },
    },

    bannerImage: {
      type: String,
      trim: true,
      default: "https://via.placeholder.com/600x200",
    },

    // 🕊️ Activity Tracking
    lastActive: {
      type: Date,
      default: Date.now,
    },
    isVerified: {
      type: Boolean,
      default: false,
    },
    isAvailableNow: {
      type: Boolean,
      default: true,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

//
// 🧠 Virtuals
//
counselorSchema.virtual("fullRole").get(function () {
  return `${this.role} (${this.experienceYears}+ yrs exp)`;
});

counselorSchema.virtual("formattedRating").get(function () {
  return `${this.rating.toFixed(1)} ⭐`;
});

counselorSchema.virtual("reviewSummary").get(function () {
  if (this.totalReviews === 0) return "No reviews yet";
  return `${this.totalReviews} review${this.totalReviews > 1 ? "s" : ""}`;
});

//
// 🚀 Indexes
//
counselorSchema.index({ name: "text", expertise: "text", city: "text" });
counselorSchema.index({ rating: -1 });
counselorSchema.index({ "location.coordinates": "2dsphere" });

//
// 🧩 Query Helpers
//
counselorSchema.query.byExpertise = function (field) {
  return this.where({ expertise: { $in: [field] }, isDeleted: false });
};

counselorSchema.query.availableNow = function () {
  return this.where({ isAvailableNow: true, isDeleted: false });
};

counselorSchema.query.verified = function () {
  return this.where({ isVerified: true, isDeleted: false });
};

//
// 🛠️ Middleware
//
counselorSchema.pre("save", function (next) {
  if (this.isModified("reviews")) {
    const totalRatings = this.reviews.reduce((sum, r) => sum + r.rating, 0);
    this.totalReviews = this.reviews.length;
    this.rating = this.totalReviews ? totalRatings / this.totalReviews : this.rating;
  }
  next();
});

counselorSchema.methods.softDelete = async function () {
  this.isDeleted = true;
  await this.save();
};

//
// 🧭 Model Export
//
const Counselor = mongoose.model("Counselor", counselorSchema);
export default Counselor;
