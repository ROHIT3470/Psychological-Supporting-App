// 🧠 personalityRoutes.js
import express from "express";
import axios from "axios";
import dotenv from "dotenv";
import colors from "colors"; // 👉 npm install colors

dotenv.config();
const router = express.Router();

// 🌍 Default Flask API endpoint (you can override in .env)
const flaskApiUrl = process.env.FLASK_API_URL || "http://127.0.0.1:5001/predict";

// 🎯 Route: POST /api/personality/predict
router.post("/predict", async (req, res) => {
  try {
    console.log("\n═══════════════════════════════════════════════════".cyan);
    console.log("🧠  Personality Prediction Request".brightCyan.bold);
    console.log("═══════════════════════════════════════════════════".cyan);
    console.log("📡 Sending data to Flask →".yellow, req.body);
    console.log(`🌐 Flask API URL : ${flaskApiUrl}`.magenta);

    // Forward the request to Flask API
    const flaskResponse = await axios.post(flaskApiUrl, req.body);

    console.log("✅ Flask Response Received!".green.bold);
    console.log("📦 Prediction Result:", flaskResponse.data);

    console.log("═══════════════════════════════════════════════════\n".cyan);
    res.status(200).json(flaskResponse.data);
  } catch (err) {
    console.log("\n═══════════════════════════════════════════════════".red);
    console.error("❌  Personality Prediction Failed!".red.bold);
    console.log("═══════════════════════════════════════════════════".red);

    const errorMsg = err.response?.data || err.message || "Unknown error";
    console.error("💥 Error:", errorMsg);

    console.log("═══════════════════════════════════════════════════\n".red);

    res.status(500).json({
      error: "Prediction failed",
      details: errorMsg,
    });
  }
});

export default router;
