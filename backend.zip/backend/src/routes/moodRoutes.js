import express from "express";
import Mood from "../models/Mood.js";

const router = express.Router();

// GET all moods
router.get("/", async (req, res) => {
  try {
    const moods = await Mood.find().sort({ createdAt: -1 });
    res.json(moods);
  } catch (err) {
    res.status(500).json({ message: "Failed to load mood data", error: err.message });
  }
});

// POST new mood
router.post("/", async (req, res) => {
  try {
    const mood = new Mood(req.body);
    const saved = await mood.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: "Error saving mood", error: err.message });
  }
});

export default router;
