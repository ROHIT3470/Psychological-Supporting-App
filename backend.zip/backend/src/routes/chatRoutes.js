import express from "express";
import Chat from "../models/Chat.js";

const router = express.Router();

// GET chat history
router.get("/", async (req, res) => {
  try {
    const messages = await Chat.find().sort({ timestamp: 1 }); // oldest first
    res.json(messages);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST add chat message
router.post("/", async (req, res) => {
  const { from, text } = req.body;
  if (!from || !text) return res.status(400).json({ error: "from and text required" });

  try {
    const msg = await Chat.create({ from, text });
    res.status(201).json(msg);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
