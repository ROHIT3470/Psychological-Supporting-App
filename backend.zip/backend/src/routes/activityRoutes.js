import express from 'express';
const router = express.Router();

// GET /api/activities - List all activities
router.get('/', (req, res) => {
    res.json({ message: 'Activities route working' });
});

export default router;
