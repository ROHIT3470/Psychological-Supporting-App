import express from "express";
import Counselor from "../models/Counselors.js";

const router = express.Router();

// GET all counselors
router.get("/", async (req, res) => {
  const counselors = await Counselor.find();
  res.json(counselors);
});

// POST new counselor
router.post("/", async (req, res) => {
  const counselor = new Counselor(req.body);
  await counselor.save();
  res.status(201).json(counselor);
});

export default router;
