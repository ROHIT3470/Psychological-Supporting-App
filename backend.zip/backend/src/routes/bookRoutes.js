import express from 'express';
const router = express.Router();

// GET /api/counselors - List available counselors
router.get('/', (req, res) => {
    res.json({ message: 'Counselors route working' });
});

// POST /api/counselors/book - Book a session
router.post('/book', (req, res) => {
    res.json({ message: 'Booking route working' });
});

export default router;
