// 🌿 connectDB.js
import mongoose from "mongoose";
import dotenv from "dotenv";
import colors from "colors"; // 👉 npm install colors

dotenv.config();

const connectDB = async () => {
  try {
    console.log("\n🔍 Checking MongoDB connection...".cyan.bold);
    console.log("───────────────────────────────────────────────");

    // Show MONGO_URI status (but hide actual value for safety)
    if (!process.env.MONGO_URI) {
      console.log("❌ MONGO_URI not found in .env file!".red.bold);
      process.exit(1);
    }

    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.clear();
    console.log("\n══════════════════════════════════════════════════════".rainbow);
    console.log("🚀  MONGO DB CONNECTION STATUS".brightGreen.bold);
    console.log("══════════════════════════════════════════════════════".rainbow);

    console.log(`${"✅ Connected Successfully!".green.bold}`);
    console.log(`${"📦 Database".yellow}: ${mongoose.connection.name}`);
    console.log(`${"🗄️  Host".yellow}: ${mongoose.connection.host}`);

    console.log("══════════════════════════════════════════════════════\n".rainbow);
  } catch (err) {
    console.clear();
    console.log("\n══════════════════════════════════════════════════════".red);
    console.log("❌  MONGO DB CONNECTION FAILED!".red.bold);
    console.log("══════════════════════════════════════════════════════".red);

    console.error(`💥 Error: ${err.message}`.brightRed);
    console.log("══════════════════════════════════════════════════════\n".red);

    process.exit(1);
  }
};

export default connectDB;
