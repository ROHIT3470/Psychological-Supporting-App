// utils/emailService.js
import nodemailer from "nodemailer";

/**
 * 🌐 Configure the mail transporter using environment variables.
 * Ensure EMAIL_USER and EMAIL_PASS are set in your .env file.
 */
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

/**
 * 📨 Send appointment confirmation emails to one or more recipients.
 * 
 * @param {string|string[]} recipients - Single email or array of emails
 * @param {Object} details - Appointment details object
 * @param {string} details.name - Recipient's name
 * @param {string} details.counselorName - Counselor name
 * @param {string} details.date - Appointment date (formatted)
 * @param {string} details.time - Appointment time
 * @param {string} [details.mode] - Session mode ("In-person" / "Online")
 * @param {string} [details.concerns] - Optional reason or message from user
 * @param {string} [details.link] - Optional online session link
 * 
 * @returns {Promise<void>} Sends emails and logs success/failure.
 */
export const sendApptConfirmation = async (recipients, details) => {
  try {
    // Convert single email to array for consistency
    const emails = Array.isArray(recipients) ? recipients : [recipients];

    // Email content
    const subject = `Appointment Confirmation — ${details.counselorName}`;
    const htmlBody = `
      <div style="font-family:Arial, sans-serif; line-height:1.6; color:#222;">
        <h2 style="color:#16a34a;">Unimindcare Appointment Confirmation</h2>
        <p>Hi ${details.name},</p>
        <p>Your session with <strong>${details.counselorName}</strong> has been successfully booked.</p>
        <table style="margin:10px 0; border-collapse:collapse;">
          <tr><td><strong>Date:</strong></td><td>${details.date}</td></tr>
          <tr><td><strong>Time:</strong></td><td>${details.time}</td></tr>
          ${details.mode ? `<tr><td><strong>Mode:</strong></td><td>${details.mode}</td></tr>` : ""}
        </table>
        ${
          details.link
            ? `<p>Join your online session here: <a href="${details.link}" target="_blank">${details.link}</a></p>`
            : ""
        }
        ${
          details.concerns
            ? `<p><strong>Your noted concerns:</strong> ${details.concerns}</p>`
            : ""
        }
        <p style="margin-top:20px;">If you need to reschedule or cancel, please contact your counselor or the Unimindcare support team.</p>
        <p>Thank you for choosing Unimindcare — your mental wellness partner.</p>
        <hr style="border:none;border-top:1px solid #ddd;margin:20px 0;">
        <p style="font-size:12px;color:#666;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `;

    // Send email to each recipient
    for (const to of emails) {
      await transporter.sendMail({
        from: `"Unimindcare" <${process.env.EMAIL_USER}>`,
        to,
        subject,
        html: htmlBody,
      });
      console.log(`✅ Appointment confirmation email sent to ${to}`);
    }
  } catch (error) {
    console.error("❌ Error sending appointment confirmation emails:", error);
    throw new Error("Failed to send appointment confirmation emails.");
  }
};

/**
 * 📅 Optional: Send group notifications to counselors or admins
 * when multiple appointments are confirmed at once.
 * 
 * @param {Array<Object>} appointments - List of appointment detail objects
 * Each appointment object should include { name, counselorName, date, time, mode, email }
 */
export const sendBulkApptNotifications = async (appointments) => {
  if (!Array.isArray(appointments) || !appointments.length) return;

  try {
    const emails = appointments.map((a) => a.email);
    const summaryList = appointments
      .map(
        (a, i) =>
          `<li><strong>${a.name}</strong> with <strong>${a.counselorName}</strong> on ${a.date} at ${a.time} (${a.mode})</li>`
      )
      .join("");

    const htmlBody = `
      <div style="font-family:Arial, sans-serif; color:#222;">
        <h3>📋 Unimindcare Appointment Summary</h3>
        <p>The following sessions have been successfully scheduled:</p>
        <ul>${summaryList}</ul>
        <p>Please ensure all users receive the necessary session details.</p>
      </div>
    `;

    await transporter.sendMail({
      from: `"Unimindcare Notifications" <${process.env.EMAIL_USER}>`,
      to: process.env.ADMIN_EMAIL || process.env.EMAIL_USER,
      bcc: emails.join(", "),
      subject: "📅 Unimindcare — New Appointment Batch Confirmation",
      html: htmlBody,
    });

    console.log("📨 Bulk appointment notifications sent successfully.");
  } catch (error) {
    console.error("❌ Failed to send bulk appointment notifications:", error);
  }
};
