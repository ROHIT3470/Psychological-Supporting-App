// utils/aiReply.js
export const aiReply = (msg = "") => {
  const m = msg.toLowerCase().trim();

  // 🚨 Crisis / safety messages
  if (/(panic|suicide|kill myself|hurt myself|die|harm|overwhelmed|danger)/.test(m)) {
    return `
⚠️ **You are not alone.**  
It sounds like you might be in deep distress right now. Please reach out for immediate help — you deserve care and safety.  
👉 Use the **Emergency** tab to call local services or contact someone you trust.  
If you’re in India, you can call **AASRA Helpline (91-9820466726)**.  
💚 For now, take 5 slow breaths. You matter, and help is available.
`;
  }

  // 📚 Study / exam / academic stress
  if (/(exam|study|assignment|project|test|college|marks)/.test(m)) {
    return `
📘 It sounds like you're focused on academics.  
Try a **Pomodoro routine** — 25 minutes of study followed by a 5-minute break.  
✅ Break big tasks into smaller chunks.  
💧 Stay hydrated, and take a few deep breaths before you begin.  
Would you like a quick study planner suggestion?
`;
  }

  // 💼 Motivation / productivity
  if (/(motivat|focus|lazy|procrastinate|inspire|goal)/.test(m)) {
    return `
💪 Staying motivated can be tough — and that’s okay.  
Try writing **one small achievable goal** for today and celebrate it when done.  
Sometimes action creates motivation, not the other way around.  
Would you like me to share a 3-step motivation exercise?
`;
  }

  // 😴 Sleep / rest guidance
  if (/(sleep|tired|insomnia|rest|exhausted|fatigue)/.test(m)) {
    return `
🌙 You might need some rest.  
Try this routine: dim the lights, put your phone away, and take slow breaths — 4s in, 4s hold, 4s out, 4s hold.  
A warm shower or light stretching before bed can also help.  
Would you like a **2-minute relaxation** exercise?
`;
  }

  // 😌 Mood / emotion reflection
  if (/(sad|happy|angry|stress|bored|lonely|anxious|depress)/.test(m)) {
    return `
💬 I hear you — emotions can be intense sometimes.  
Try naming what you feel: “I feel ___ because ___.”  
That small step helps your brain process it.  
You could also check the **Activities tab** for something uplifting.  
Would you like to log your mood right now?
`;
  }

  // ❤️ Relationships / social connection
  if (/(friend|relationship|family|love|breakup|alone|partner)/.test(m)) {
    return `
❤️ Relationships deeply affect our mood.  
Remember — it’s okay to set boundaries and express your feelings honestly.  
If you’re feeling isolated, try reaching out to one person you trust today.  
Would you like a short reflection activity on relationships?
`;
  }

  // 🧘 Health / mindfulness
  if (/(health|anxiety|breath|mindful|meditate|yoga)/.test(m)) {
    return `
🧘 Taking care of your body and mind really matters.  
Try a **2-minute breathing** or grounding exercise:  
Name 5 things you see, 4 you can touch, 3 you hear, 2 you smell, 1 you taste.  
Would you like me to walk you through that?
`;
  }

  // 🌞 Gratitude or positive mood
  if (/(grateful|thankful|gratitude|blessed|good day)/.test(m)) {
    return `
🌼 That’s wonderful! Practicing gratitude strengthens emotional resilience.  
Try writing down **3 things you’re thankful for today** — big or small.  
Would you like to save them in your journal?
`;
  }

  // 💬 Default empathetic fallback
  return `
🤖 I'm here for you.  
Tell me more about what's been on your mind lately.  
You can also try logging your mood or exploring the **Activities** tab for support ideas.
`;
};
