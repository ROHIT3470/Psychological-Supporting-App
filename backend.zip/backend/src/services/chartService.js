// src/services/chartService.js
import axios from "axios";

const API_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";

/**
 * 🔹 Get mood history for a user
 * @returns {Promise<Array>} - Array of mood entries with { date, mood, note }
 */
export const fetchMoodHistory = async () => {
  try {
    const response = await axios.get(`${API_URL}/api/moods`);
    return response.data || [];
  } catch (error) {
    console.error("❌ Error fetching mood history:", error.message);
    return [];
  }
};

/**
 * 🔹 Prepare line chart data for mood trends
 * Converts moods into Chart.js-friendly format
 * @param {Array} moodData - Raw mood entries from API
 * @returns {Object} Chart.js config data
 */
export const buildMoodTrendData = (moodData = []) => {
  const sorted = [...moodData].sort(
    (a, b) => new Date(a.date) - new Date(b.date)
  );

  return {
    labels: sorted.map(
      (e) => new Date(e.date).toLocaleDateString("en-IN", { day: "2-digit", month: "short" })
    ),
    datasets: [
      {
        label: "Mood Level",
        data: sorted.map((e) => e.mood),
        borderColor: "#16a34a",
        backgroundColor: "rgba(34,197,94,0.15)",
        borderWidth: 2,
        tension: 0.3,
        fill: true,
        pointRadius: 4,
      },
    ],
  };
};

/**
 * 🔹 Prepare pie chart data for mood distribution
 * @param {Array} moodData - Raw mood entries from API
 * @returns {Object} Chart.js pie dataset
 */
export const buildMoodDistributionData = (moodData = []) => {
  const counts = [0, 0, 0, 0, 0];
  moodData.forEach((e) => {
    if (e.mood >= 1 && e.mood <= 5) counts[e.mood - 1]++;
  });

  return {
    labels: ["Very Low (1)", "Low (2)", "Okay (3)", "Good (4)", "Great (5)"],
    datasets: [
      {
        data: counts,
        backgroundColor: [
          "#ef4444", // red
          "#f97316", // orange
          "#facc15", // yellow
          "#22c55e", // green
          "#10b981", // emerald
        ],
        borderWidth: 1,
      },
    ],
  };
};

/**
 * 🔹 Calculate average mood score
 * @param {Array} moodData
 * @returns {number} - average mood (1–5 scale)
 */
export const calculateAverageMood = (moodData = []) => {
  if (!moodData.length) return 0;
  const total = moodData.reduce((sum, e) => sum + e.mood, 0);
  return Number((total / moodData.length).toFixed(2));
};

/**
 * 🔹 Combined helper: fetch + process all chart data
 * @returns {Promise<{trendData, distributionData, averageMood}>}
 */
export const getChartData = async () => {
  const moodData = await fetchMoodHistory();
  return {
    trendData: buildMoodTrendData(moodData),
    distributionData: buildMoodDistributionData(moodData),
    averageMood: calculateAverageMood(moodData),
  };
};
