import axios from "axios";
import CryptoJS from "crypto-js";

// ✅ Use environment variable for flexibility
const BASE_URL = import.meta.env.VITE_API_URL || "https://localhost:5000/api";

// ✅ Create a reusable Axios instance
const api = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  withCredentials: true, // Useful if backend uses cookies
  headers: {
    "Content-Type": "application/json",
  },
});

// ✅ Automatically attach access token to all requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("accessToken");
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// ✅ Centralized error handler
const handleError = (error) => {
  if (error.response) {
    const { status, data } = error.response;
    const message = data?.message || "An error occurred";

    switch (status) {
      case 400:
        return { success: false, message: "Bad Request" };
      case 401:
        localStorage.removeItem("accessToken");
        localStorage.removeItem("refreshToken");
        return { success: false, message: "Unauthorized — please log in again." };
      case 403:
        return { success: false, message: "Forbidden — insufficient permissions." };
      case 404:
        return { success: false, message: "Resource not found." };
      case 500:
        return { success: false, message: "Server error. Please try later." };
      default:
        return { success: false, message };
    }
  }
  // No server response (network or timeout)
  return { success: false, message: "Network error. Please check your connection." };
};

// ✅ Blockchain-inspired tamper-proof hash
const generateSecureHash = (username, timestamp) => {
  const secretKey = import.meta.env.VITE_HASH_SECRET || "mySuperSecretKey";
  return CryptoJS.HmacSHA256(`${username}-${timestamp}`, secretKey).toString(CryptoJS.enc.Hex);
};

// ✅ Universal helper: safely store tokens
const saveTokens = (data) => {
  if (data.accessToken) localStorage.setItem("accessToken", data.accessToken);
  if (data.refreshToken) localStorage.setItem("refreshToken", data.refreshToken);
};

// ✅ Refresh token logic (optional if backend supports it)
export const refreshAccessToken = async () => {
  try {
    const refreshToken = localStorage.getItem("refreshToken");
    if (!refreshToken) return null;

    const res = await api.post("/auth/refresh", { refreshToken });
    if (res.accessToken) localStorage.setItem("accessToken", res.accessToken);
    return res.accessToken;
  } catch {
    logoutUser();
    return null;
  }
};

// ✅ Register user
export const registerUser = async (data) => {
  try {
    const timestamp = Date.now();
    const hash = generateSecureHash(data.username, timestamp);
    const res = await api.post("/auth/register", { ...data, hash, timestamp });
    return { success: true, data: res };
  } catch (err) {
    return handleError(err);
  }
};

// ✅ Login user
export const loginUser = async (data) => {
  try {
    const timestamp = Date.now();
    const hash = generateSecureHash(data.username, timestamp);
    const res = await api.post("/auth/login", { ...data, hash, timestamp });

    saveTokens(res);
    return { success: true, data: res };
  } catch (err) {
    return handleError(err);
  }
};

// ✅ Logout user
export const logoutUser = () => {
  localStorage.removeItem("accessToken");
  localStorage.removeItem("refreshToken");
  return { success: true, message: "Logged out successfully" };
};

// ✅ Generic GET/POST/PUT/DELETE for reusability
export const getData = async (endpoint, params = {}) => {
  try {
    const res = await api.get(endpoint, { params });
    return { success: true, data: res };
  } catch (err) {
    return handleError(err);
  }
};

export const postData = async (endpoint, body) => {
  try {
    const res = await api.post(endpoint, body);
    return { success: true, data: res };
  } catch (err) {
    return handleError(err);
  }
};

export const putData = async (endpoint, body) => {
  try {
    const res = await api.put(endpoint, body);
    return { success: true, data: res };
  } catch (err) {
    return handleError(err);
  }
};

export const deleteData = async (endpoint) => {
  try {
    const res = await api.delete(endpoint);
    return { success: true, data: res };
  } catch (err) {
    return handleError(err);
  }
};

export default api;
