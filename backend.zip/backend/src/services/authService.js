import axios from "axios";
import CryptoJS from "crypto-js";


const BASE_URL = "https://localhost:5000/api/auth"; // Use HTTPS in production

// Create axios instance for API calls
const api = axios.create({
  baseURL: BASE_URL,
  timeout: 10000, // 10 seconds
  headers: {
    "Content-Type": "application/json",
  },
});

// Axios interceptor to attach token automatically
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("accessToken");
    if (token) config.headers["Authorization"] = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// User-friendly error handler
const handleError = (error) => {
  if (!error.response) {
    return { success: false, message: "Network error. Please try again." };
  }
  return { success: false, message: error.response.data.message || "An error occurred" };
};

// Optional blockchain-like login hash (tamper-proof)
const generateLoginHash = (username, timestamp) => {
  return CryptoJS.SHA256(`${username}-${timestamp}`).toString(CryptoJS.enc.Hex);
};

// Register user
export const registerUser = async (data) => {
  try {
    const timestamp = Date.now();
    const hash = generateLoginHash(data.username, timestamp);

    const res = await api.post("/register", { ...data, loginHash: hash, timestamp });
    return { success: true, data: res.data };
  } catch (err) {
    return handleError(err);
  }
};

// Login user
export const loginUser = async (data) => {
  try {
    const timestamp = Date.now();
    const hash = generateLoginHash(data.username, timestamp);

    const res = await api.post("/login", { ...data, loginHash: hash, timestamp });

    // Save tokens securely
    if (res.data.accessToken) localStorage.setItem("accessToken", res.data.accessToken);
    if (res.data.refreshToken) localStorage.setItem("refreshToken", res.data.refreshToken);

    return { success: true, data: res.data };
  } catch (err) {
    return handleError(err);
  }
};

// Logout user
export const logoutUser = () => {
  localStorage.removeItem("accessToken");
  localStorage.removeItem("refreshToken");
  return { success: true, message: "Logged out successfully" };
};
