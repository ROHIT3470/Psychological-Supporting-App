// 🌐 server.js

// ===== Core Imports =====
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';

// ===== Internal Config =====
import connectDB from './src/config/db.js';

// ===== Middlewares =====
import errorHandler from './src/middleware/errorHandler.js'; // ✅ fixed

// ===== Route Imports =====
import authRoutes from './src/routes/authRoutes.js';
import moodRoutes from './src/routes/moodRoutes.js';
import apptRoutes from './src/routes/activityRoutes.js';
import counselorsRoutes from './src/routes/bookRoutes.js';
import chatRoutes from './src/routes/chatRoutes.js';
import personalityRoutes from './src/routes/personalityRoutes.js'; // 🧠 ML Route
// ===== Initialize App =====
const app = express();

// ===== Connect Database =====
connectDB();

// ===== Global Middlewares =====
app.use(cors()); // ✅ simpler & reliable
app.use(express.json());
app.use(morgan('dev'));

// (Optional: apply validateRequest / authMiddleware only in specific routes)
// app.use(validateRequest);
// app.use(authMiddleware);

// ===== API Routes =====
app.use('/api/auth', authRoutes);
app.use('/api/mood', moodRoutes);
app.use('/api/appointments', apptRoutes);
app.use('/api/counselors', counselorsRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/personality', personalityRoutes); // 🧠 AI/ML Integration

// ===== Root Endpoint =====
app.get('/', (req, res) => {
  res.send('✨ Mental Health & Personality Prediction API is running...');
});

// ===== Error Handler =====
app.use(errorHandler);

// ===== Start Server =====
const PORT = process.env.PORT || 5000;
app.listen(PORT, () =>
  console.log(`🚀 Server running on port ${PORT}`)
);
